﻿// See https://aka.ms/new-console-template for more information
Console.Write("Ingrese su nombre: ");
string nombre = Console.ReadLine();
Console.WriteLine("Hola " + nombre);
Console.Write("Desea continuar? Ingrese S o N : ");
string opcion = Console.ReadLine();


if(opcion == "S"){
    while(opcion == "S"){
        Console.Write("Ingrese su nombre: ");
        string nombre1 = Console.ReadLine();
        Console.WriteLine("Hola " + nombre1);
        Console.Write("Desea continuar? Ingrese S o N : ");
        string opcion1 = Console.ReadLine();
        opcion= opcion1;
    }
    Console.WriteLine("Programa finalizado correctamente");
}
else if(opcion=="N"){
    Console.WriteLine("Programa finalizado correctamente");
}
else{
    Console.WriteLine("Opcion no valida");
}
