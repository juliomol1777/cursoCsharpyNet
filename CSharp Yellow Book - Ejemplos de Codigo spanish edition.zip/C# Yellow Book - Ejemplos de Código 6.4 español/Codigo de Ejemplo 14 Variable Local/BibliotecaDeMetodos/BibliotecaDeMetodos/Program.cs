﻿using System;
    class BibliotecaDeMetodos
    {
    static string leerCadena(string prompt)
    {
        string resultado;
        do
        {
            Console.Write(prompt);
            resultado = Console.ReadLine();
        } while (resultado == "");
        return resultado;
    }

    static int leerEntero(string prompt, int minimo, int maximo)
    {
        int resultado;

        do
        {
            string cadenaEntero = leerCadena(prompt);
            resultado = int.Parse(cadenaEntero);
        } while ((resultado < minimo) || (resultado > maximo));

        return resultado;
    }

    public static void Main()
    {
        string nombre;
        nombre = leerCadena("Introduzca su nombre: ");
        Console.WriteLine("Nombre: " + nombre);

        int edad;
        edad = leerEntero("Introduzca su edad: ", 0, 100);
        Console.WriteLine("Edad: " + edad);
        Console.ReadKey();
    }
}