﻿using System;

    class Program
    {
        static void Main(string[] args)
        {
            int i = 3, j = 2;
            float fraccion;
            fraccion = (float)i / (float)j;
            Console.WriteLine("fracción : " + fraccion);
            Console.ReadKey();
         }
    }