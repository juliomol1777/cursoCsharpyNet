﻿using System;

class Cuenta
{
    public string Nombre;
};

class DemoEstructurasYObjetos
{
    public static void Main()
    {
        Cuenta CuentaDeRob;
        CuentaDeRob = new Cuenta();
        CuentaDeRob.Nombre = "Rob";
        Console.WriteLine(CuentaDeRob.Nombre);
        CuentaDeRob = new Cuenta();
        CuentaDeRob.Nombre = "Jim";
        Console.WriteLine(CuentaDeRob.Nombre);
        Console.ReadKey();
    }
}