﻿using System;
    class DemoMatriz
    {
        static string leerCadena(string prompt)
        {
            string resultado;
            do
            {
                Console.Write(prompt);
                resultado = Console.ReadLine();
            } while (resultado == "");
            return resultado;
        }

        static int leerEntero(string prompt, int minimo, int maximo)
        {
            int resultado;

            do
            {
                string cadenaEntero = leerCadena(prompt);
                resultado = int.Parse(cadenaEntero);
            } while ((resultado < minimo) || (resultado > maximo));

            return resultado;
        }
        static void Main(string[] args)
        {
            const int TAMAÑO_MATRIZ_PUNTUACIONES = 10;
            int[] puntuaciones = new int[TAMAÑO_MATRIZ_PUNTUACIONES];
            for (int i = 0; i < TAMAÑO_MATRIZ_PUNTUACIONES; i = i + 1)
            {
                puntuaciones[i] = leerEntero("Puntuación : ", 0, 1000);
            }

            // Ahora imprime las puntuaciones

            for (int i = 0; i < TAMAÑO_MATRIZ_PUNTUACIONES; i = i + 1)
            {
                Console.WriteLine("Puntuación: " + puntuaciones[i]);
            }
            Console.ReadKey();
        }
    }