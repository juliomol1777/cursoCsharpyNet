﻿using System;
    class EjemploMiembro
    {
        // la variable miembro es parte de la clase
        static int miembro = 0;

        static void OtroMetodo()
        {
            miembro = 99;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("miembro vale: " + miembro);
            OtroMetodo();
            Console.WriteLine("miembro vale ahora: " + miembro);
            Console.ReadKey();
        }
    }