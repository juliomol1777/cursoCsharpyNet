﻿using System;

public interface ICuenta
{
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
}

public class CuentaCliente : ICuenta
{

    private decimal saldo = 0;

    public virtual bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }
}

public class CuentaInfantil : CuentaCliente, ICuenta
{
    public override bool RetirarEfectivo(decimal cantidad)
    {
        if (cantidad > 10)
        {
            return false;
        }
        return base.RetirarEfectivo(cantidad);
    }
}

class Banco
{
    const int MAX_CLIENTES = 100;

    public static void Main()
    {
        ICuenta[] cuentas = new ICuenta[MAX_CLIENTES];

        cuentas[0] = new CuentaCliente();
        cuentas[0].IngresarEfectivo(50);
        Console.WriteLine("Saldo: " + cuentas[0].ObtenerSaldo());

        cuentas[1] = new CuentaInfantil();
        cuentas[1].IngresarEfectivo(20);
        Console.WriteLine("Saldo: " + cuentas[1].ObtenerSaldo());

        if (cuentas[0].RetirarEfectivo(20))
        {
            Console.WriteLine("Retirada de efectivo correcta");
        }
        if (cuentas[1].RetirarEfectivo(20))
        {
            Console.WriteLine("Retirada de efectivo correcta");
        }
        Console.ReadKey();
    }
}