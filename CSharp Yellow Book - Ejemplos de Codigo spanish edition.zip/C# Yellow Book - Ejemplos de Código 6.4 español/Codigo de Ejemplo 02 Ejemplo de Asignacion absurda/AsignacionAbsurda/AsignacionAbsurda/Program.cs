﻿using System;

    class AsignacionTonta
    {
        static void Main(string[] args)
        {
            int primero, segundo, tercero;
            primero = 1;
            segundo = 2;
            tercero = segundo + primero;
            Console.WriteLine(primero);
            Console.WriteLine(segundo);
            Console.WriteLine(tercero);
            Console.ReadKey();
        }
    }