﻿using System;

class Cuenta
{
    private string nombre;
    private decimal saldo;

    public override string ToString()
    {
        return "Nombre: " + nombre + " saldo: " + saldo;
    }

    public Cuenta(string enNombre, decimal enSaldo)
    {
        nombre = enNombre;
        saldo = enSaldo;
    }
}

class Banco
{
    public static void Main()
    {
        Cuenta a = new Cuenta("Rob", 25);
        Console.WriteLine(a);
        Console.ReadKey();
    }
}