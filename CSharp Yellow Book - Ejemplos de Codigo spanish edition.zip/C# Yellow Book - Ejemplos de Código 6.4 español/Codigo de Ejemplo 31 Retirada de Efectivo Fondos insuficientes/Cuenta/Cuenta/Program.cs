﻿using System;

class Cuenta
{
    private decimal saldo = 0;

    public bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }
};

class Banco
{
    public static void Main()
    {
        Cuenta CuentaDeRob;
        CuentaDeRob = new Cuenta();
        if (CuentaDeRob.RetirarEfectivo(5))
        {
            Console.WriteLine("Efectivo retirado correctamente");
        }
        else
        {
            Console.WriteLine("Fondos insuficientes");
        }
    Console.ReadKey();
    }
}