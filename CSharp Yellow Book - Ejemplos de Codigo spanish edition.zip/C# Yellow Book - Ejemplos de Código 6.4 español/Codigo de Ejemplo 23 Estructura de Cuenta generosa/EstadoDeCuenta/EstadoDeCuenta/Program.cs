﻿using System;

    enum EstadoCuenta
    {
        Nueva,
        Activa,
        BajoAuditoria,
        Congelada,
        Cerrada
    };

    struct Cuenta
    {
        public EstadoCuenta Estado;
        public string Nombre;
        public string Direccion;
        public int NumeroCuenta;
        public int Saldo;
        public int Descubierto;
    };

    class ProgramaBancario
    {
        static void Main(string[] args)
        {
            Cuenta CuentaDeRob;
            CuentaDeRob.Estado = EstadoCuenta.Activa;
            CuentaDeRob.Saldo = 1000000;
        }
    }