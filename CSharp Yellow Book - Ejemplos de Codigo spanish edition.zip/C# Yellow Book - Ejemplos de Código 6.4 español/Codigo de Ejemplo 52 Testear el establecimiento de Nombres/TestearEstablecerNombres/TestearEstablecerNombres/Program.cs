﻿using System;

class CuentaCliente
{
    private string nombre;

    public string ObtenerNombre()
    {
        return this.nombre;
    }

    public static string ValidarNombre(string nombre)
    {
        if (nombre == null)
        {
            return "Parámetro nombre null";
        }
        string nombreDeEspaciosEnBlanco = nombre.Trim();
        if (nombreDeEspaciosEnBlanco.Length == 0)
        {
            return "El nombre introducido no contiene texto";
        }
        return "";
    }

    public bool EstablecerNombre(string enNombre)
    {
        string respuesta;
        respuesta = ValidarNombre(enNombre);
        if (respuesta.Length > 0)
        {
            return false;
        }

        this.nombre = enNombre.Trim();
        return true;
    }

    private decimal saldo;

    public CuentaCliente(string enNombre, decimal enSaldo)
    {
        string respuesta = "";

        string validar = ValidarNombre(enNombre);
        if (validar != "")
            respuesta = respuesta + validar;

        // Realmente debería realizar la validación del saldo aquí
        saldo = enSaldo;

        // Falla si hay algún mensaje de error
        if (respuesta != "")
            throw new Exception(respuesta);
    }
}

class TestearNombre
{
    public static void HacerSonarSirena()
    {
        Console.WriteLine("Insertar el sonido fuerte aquí");
    }

    public static void Main()
    {
        int contadorDeErrores = 0;
        string respuesta;
        respuesta = CuentaCliente.ValidarNombre(null);
        if (respuesta != "Parámetro nombre null")
        {
            Console.WriteLine("Prueba de nombre null fallida");
            contadorDeErrores++;
        }
        respuesta = CuentaCliente.ValidarNombre("");
        if (respuesta != "El nombre introducido no contiene texto")
        {
            Console.WriteLine("Prueba de nombre vacío fallida");
            contadorDeErrores++;
        }
        respuesta = CuentaCliente.ValidarNombre("   ");
        if (respuesta != "El nombre introducido no contiene texto")
        {
            Console.WriteLine("Prueba de Nombre con cadena en blanco fallida");
            contadorDeErrores++;
        }
        CuentaCliente a = new CuentaCliente("Rob", 50);

        if (!a.EstablecerNombre("Jim"))
        {
            Console.WriteLine("EstablecerNombre Jim fallido");
            contadorDeErrores++;
        }
        if (a.ObtenerNombre() != "Jim")
        {
            Console.WriteLine("ObtenerNombre Jim fallido");
            contadorDeErrores++;
        }
        if (!a.EstablecerNombre("   Pete   "))
        {
            Console.WriteLine("EstablecerNombre Pete Espacios en blanco eliminados fallido");
            contadorDeErrores++;
        }
        if (a.ObtenerNombre() != "Pete")
        {
            Console.WriteLine("ObtenerNombre Pete fallido");
            contadorDeErrores++;
        }
        if (contadorDeErrores > 0)
        {
            HacerSonarSirena();
        }
    }
}