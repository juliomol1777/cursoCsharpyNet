﻿using System;

public class Cuenta
{
    private decimal saldo = 0;

    public bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }
}

class Banco
{
    public static void Main()
    {
        Cuenta prueba = new Cuenta();
        prueba.IngresarEfectivo(50);
        if (prueba.ObtenerSaldo() != 50)
        {
            Console.WriteLine("Prueba de Ingreso de efectivo fallida");
        }
        else
        {
            Console.WriteLine("Prueba de Ingreso de efectivo correcta");
        }
        Console.ReadKey();
    }
}