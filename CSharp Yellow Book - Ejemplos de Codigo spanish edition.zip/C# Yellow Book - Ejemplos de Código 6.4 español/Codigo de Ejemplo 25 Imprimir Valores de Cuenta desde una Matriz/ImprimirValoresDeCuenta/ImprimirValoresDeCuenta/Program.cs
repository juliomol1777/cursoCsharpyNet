﻿using System;

    enum EstadoCuenta
    {
        Nueva,
        Activa,
        BajoAuditoria,
        Congelada,
        Cerrada
    };

    struct Cuenta
    {
        public EstadoCuenta Estado;
        public string Nombre;
        public string Direccion;
        public int NumeroCuenta;
        public int Saldo;
        public int Descubierto;
    };

class ProgramaBancario
    {
        public static void ImprimirCuenta(Cuenta a)
    {
            Console.WriteLine("Nombre: " + a.Nombre);
            Console.WriteLine("Dirección: " + a.Direccion);
            Console.WriteLine("Saldo: " + a.Saldo);
        }
        static void Main(string[] args)
        {
            const int MAX_CLIENTES = 100;
            Cuenta[] Banco = new Cuenta[MAX_CLIENTES];
            Banco[0].Nombre = "Rob";
            Banco[0].Direccion = "Domicilio de Rob";
            Banco[0].Estado = EstadoCuenta.Activa;
            Banco[0].Saldo = 1000000;
            ImprimirCuenta(Banco[0]);
            Banco[1].Nombre = "Jim";
            Banco[1].Direccion = "Domicilio de Jim";
            Banco[1].Estado = EstadoCuenta.Congelada;
            Banco[1].Saldo = 0;
            ImprimirCuenta(Banco[1]);
            Console.ReadKey();
        }
    }