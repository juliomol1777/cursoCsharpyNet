﻿using System;

public delegate decimal CalcularTasa(decimal saldo);

public class DemoDelegado
{
    public static decimal TasaEstafa(decimal saldo)
    {
        Console.WriteLine("Llamar al método Estafa");
        if (saldo < 0)
        {
            return 100;
        }
        else
        {
            return 1;
        }
    }

    public static decimal TasaAmistosa(decimal saldo)
    {
        Console.WriteLine("Llamar al método Amistoso");
        if (saldo < 0)
        {
            return 10;
        }
        else
        {
            return 1;
        }
    }

    public static void Main()
    {
        CalcularTasa calc;

        calc = new CalcularTasa(TasaEstafa);
        calc(-1); // esta instrucción llamará al método Estafa
        calc = new CalcularTasa(TasaAmistosa);
        calc(-1); // esta instrucción llamará al método Amistoso

        Console.ReadKey();
    }
}