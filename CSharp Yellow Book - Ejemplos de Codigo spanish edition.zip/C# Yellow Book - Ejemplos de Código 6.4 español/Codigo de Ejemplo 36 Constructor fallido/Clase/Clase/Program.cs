﻿using System;

class Cuenta
{
    // miembros de datos privados
    private string nombre;
    private string direccion;
    private decimal saldo;

    public bool EstablecerNombre(string enNombre)
    {
        if (enNombre == "")
            return false;

        nombre = enNombre;

        return true;
    }

    public bool EstablecerDireccion(string enDireccion)
    {
        if (enDireccion == "")
            return false;

        direccion = enDireccion;

        return true;
    }

    const decimal MAX_SALDO = 10000000;
    const decimal MIN_SALDO = -10000000;

    public bool EstablecerSaldo(decimal enSaldo)
    {
        if (enSaldo < MIN_SALDO ||
            enSaldo > MAX_SALDO)
            return false;

        saldo = enSaldo;
        return true;
    }

    // constructores
    public Cuenta(string enNombre, string enDireccion,
      decimal enSaldo)
    {
        string mensajeError = "";

        if (EstablecerSaldo(enSaldo) == false)
            mensajeError = mensajeError + "Saldo no válido: " + enSaldo;

        if (EstablecerNombre(enNombre) == false)
        {
            mensajeError = mensajeError + "Nombre no válido: " + enNombre;
        }

        if (EstablecerDireccion(enDireccion) == false)
        {
            mensajeError = mensajeError + "Dirección no válida: " + enDireccion;
        }

        if (mensajeError != "")
        {
            throw new Exception("Creación de la cuenta fallida "
                + mensajeError);
        }
    }

    public Cuenta(string enNombre):
        this(enNombre, "No Suministrado", 0)
    {
    }
}

class Banco
{
    public static void Main()
    {
        const int MAX_CLIENTES = 100;
        Cuenta[] Cuentas = new Cuenta[MAX_CLIENTES];
        Cuentas[0] = new Cuenta("Rob", "", 1000000);
    }
}