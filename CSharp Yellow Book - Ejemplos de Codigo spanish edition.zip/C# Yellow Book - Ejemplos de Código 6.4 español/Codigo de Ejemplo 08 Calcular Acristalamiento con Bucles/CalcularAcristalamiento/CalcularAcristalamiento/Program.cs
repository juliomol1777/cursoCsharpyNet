﻿using System;
    class CalcularAcristalamiento
    {
        static void Main(string[] args)
        {
            double anchura, altura, longitudMadera, areaVidrio;
            const double MAX_ANCHURA = 5.0;
            const double MIN_ANCHURA = 0.5;
            const double MAX_ALTURA = 3.0;
            const double MIN_ALTURA = 0.75;
            string cadenaAnchura, cadenaAltura;

            do
            {
                Console.Write("Introduzca anchura de la ventana entre " +
                MIN_ANCHURA + " y " + MAX_ANCHURA + ": ");
                cadenaAnchura = Console.ReadLine();
                anchura = double.Parse(cadenaAnchura);
            } while (anchura < MIN_ANCHURA || anchura > MAX_ANCHURA);

            do
            {
                Console.Write("Introduzca altura de la ventana entre " +
                MIN_ALTURA + " y " + MAX_ALTURA + ": ");
                cadenaAltura = Console.ReadLine();
                altura = double.Parse(cadenaAltura);
            } while (altura < MIN_ALTURA || altura > MAX_ALTURA);

            longitudMadera = 2 * (anchura + altura) * 3.25;

            areaVidrio = 2 * (anchura * altura);

            Console.WriteLine("La longitud de la madera es de " +
            longitudMadera + " pies");
            Console.WriteLine("El área de vidrio es de " +
            areaVidrio + " metros cuadrados");

            Console.ReadKey();
        }
    }