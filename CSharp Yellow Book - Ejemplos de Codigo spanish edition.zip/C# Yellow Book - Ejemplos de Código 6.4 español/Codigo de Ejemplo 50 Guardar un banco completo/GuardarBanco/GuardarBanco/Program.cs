﻿using System;
using System.Collections.Generic;

public interface ICuenta
{
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
    string ObtenerNombre();
}

public class Cuenta : ICuenta
{
    public Cuenta(
        string nuevoNombre,
        decimal saldoInicial)
    {
        nombre = nuevoNombre;
        saldo = saldoInicial;
    }

    private decimal saldo = 0;
    private string nombre;

    public virtual bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }

    public string ObtenerNombre()
    {
        return nombre;
    }
    public void Guardar(System.IO.TextWriter textoDeSalida)
    {
        textoDeSalida.WriteLine(nombre);
        textoDeSalida.WriteLine(saldo);
    }

    public bool Guardar(string nombredearchivo)
    {
        System.IO.TextWriter textoDeSalida = null;
        try
        {
            textoDeSalida = new System.IO.StreamWriter(nombredearchivo);
            Guardar(textoDeSalida);
        }
        catch
        {
            return false;
        }
        finally
        {
            if (textoDeSalida != null)
            {
                textoDeSalida.Close();
            }
        }
        return true;
    }

    public static Cuenta Cargar(
        System.IO.TextReader textoEn)
    {
        Cuenta resultado = null;

        try
        {
            string nombre = textoEn.ReadLine();
            string textoSaldo = textoEn.ReadLine();
            decimal saldo = decimal.Parse(textoSaldo);
            resultado = new Cuenta(nombre, saldo);
        }
        catch
        {
            return null;
        }
        return resultado;
    }

    public static Cuenta Cargar(string nombredearchivo)
    {
        System.IO.TextReader textoEn = null;
        Cuenta resultado = null;
        try
        {
            textoEn = new System.IO.StreamReader(nombredearchivo);
            resultado = Cuenta.Cargar(textoEn);
        }
        catch
        {
            return null;
        }
        finally
        {
            if (textoEn != null) textoEn.Close();
        }

        return resultado;
    }
}

class DiccionarioBancario
{
    Dictionary<string, ICuenta> diccionarioDeCuentas = new Dictionary<string, ICuenta>();

    public ICuenta EncontrarCuenta(string nombre)
    {
        if (diccionarioDeCuentas.ContainsKey(nombre) == true)
            return diccionarioDeCuentas[nombre];
        else
            return null;
    }

    public bool AlmacenarCuenta(ICuenta cuenta)
    {
        if (diccionarioDeCuentas.ContainsKey(cuenta.ObtenerNombre()) == true)
            return false;

        diccionarioDeCuentas.Add(cuenta.ObtenerNombre(), cuenta);
        return true;
    }

    public void Guardar(System.IO.TextWriter textoDeSalida)
    {
        textoDeSalida.WriteLine(diccionarioDeCuentas.Count);
        foreach (Cuenta cuenta in diccionarioDeCuentas.Values)
        {
            cuenta.Guardar(textoDeSalida);
        }
    }

    public bool Guardar(string nombredearchivo)
    {
        System.IO.TextWriter textoDeSalida = null;
        try
        {
            textoDeSalida = new System.IO.StreamWriter(nombredearchivo);
            Guardar(textoDeSalida);
        }
        catch
        {
            return false;
        }
        finally
        {
            if (textoDeSalida != null)
            {
                textoDeSalida.Close();
            }
        }
        return true;
    }

    public static DiccionarioBancario Cargar(System.IO.TextReader textoEn)
    {
        DiccionarioBancario resultado = new DiccionarioBancario();
        string contarCadena = textoEn.ReadLine();
        int contador = int.Parse(contarCadena);

        for (int i = 0; i < contador; i++)
        {
            Cuenta cuenta = Cuenta.Cargar(textoEn);
            resultado.diccionarioDeCuentas.Add(cuenta.ObtenerNombre(), cuenta);
        }
        return resultado;
    }

    public static DiccionarioBancario Cargar(string nombredearchivo)
    {
        System.IO.TextReader textoEn = null;
        DiccionarioBancario resultado = null;
        try
        {
            textoEn = new System.IO.StreamReader(nombredearchivo);
            resultado = DiccionarioBancario.Cargar(textoEn);
        }
        catch
        {
            return null;
        }
        finally
        {
            if (textoEn != null) textoEn.Close();
        }

        return resultado;
    }

}

class ProgramaBancario
{
    public static void Main()
    {
        DiccionarioBancario nuestroBanco = new DiccionarioBancario();

        Cuenta nuevaCuenta = new Cuenta("Rob", 1000000);

        if (nuestroBanco.AlmacenarCuenta(nuevaCuenta) == true)
            Console.WriteLine("Cuenta añadida al banco");

        nuestroBanco.Guardar("Prueba.txt");

        DiccionarioBancario cargarBanco = DiccionarioBancario.Cargar("Prueba.txt");

        ICuenta cuentaAlmacenada = nuestroBanco.EncontrarCuenta("Rob");
        if (cuentaAlmacenada != null)
            Console.WriteLine("Cuenta encontrada en el banco");

        Console.ReadKey();
    }
}