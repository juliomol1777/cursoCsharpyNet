﻿using System;

public interface ICuenta
{
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
    string ObtenerNombre();
}

public class CuentaCliente : ICuenta
{
    public CuentaCliente(
        string nuevoNombre,
        decimal saldoInicial)
    {
        nombre = nuevoNombre;
        saldo = saldoInicial;
    }

    private decimal saldo = 0;
    private string nombre;

    public virtual bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }

    public string ObtenerNombre()
    {
        return nombre;
    }
    public bool Guardar(string nombredearchivo)
    {
        try
        {
            System.IO.TextWriter textoDeSalida =
                new System.IO.StreamWriter(nombredearchivo);
            textoDeSalida.WriteLine(nombre);
            textoDeSalida.WriteLine(saldo);
            textoDeSalida.Close();
        }
        catch
        {
            return false;
        }
        return true;
    }
    public static CuentaCliente Cargar(string nombredearchivo)
    {
        CuentaCliente resultado = null;
        System.IO.TextReader textoEn = null;

        try
        {
            textoEn = new System.IO.StreamReader(nombredearchivo);
            string textoNombre = textoEn.ReadLine();
            string textoSaldo = textoEn.ReadLine();
            decimal saldo = decimal.Parse(textoSaldo);
            resultado = new CuentaCliente(textoNombre, saldo);
        }
        catch
        {
            return null;
        }
        finally
        {
            if (textoEn != null) textoEn.Close();
        }
        return resultado;
    }
}

class DemoGuardar
{
    public static void Main()
    {
        CuentaCliente prueba = new CuentaCliente("Rob", 1000000);
        prueba.Guardar("Prueba.txt");

        CuentaCliente cargada = CuentaCliente.Cargar("Prueba.txt");
        Console.WriteLine(cargada.ObtenerNombre());

        Console.ReadKey();
    }
}