﻿using System;

    class BucleInfinito
    {
        static void Main(string[] args)
        {
            do
                Console.WriteLine("Hola, mamá");
            while (true);
        }
    }