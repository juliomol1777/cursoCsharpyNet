﻿using System;
    class DemostracionRetornarValor
    {
        static int absurdoRetornoDeSuma(int i)
        {
            i = i + 1;
            Console.WriteLine("i vale: " + i);
            return i;
        }
        static void Main(string[] args)
        {
            int resultado;
            resultado = absurdoRetornoDeSuma(5);
            Console.WriteLine("El resultado es: " + resultado);
            Console.ReadKey();
        }
    }