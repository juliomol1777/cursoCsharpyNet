﻿using System;
    class MetodoUtil
    {
        static double leerValor(
            string prompt, // mensaje para el usuario desde la línea de comandos 
            double minimo, // valor mínimo permitido
            double maximo  // valor máximo permitido
            )
        {
            double resultado = 0;
            do
            {
                Console.WriteLine(prompt +
                    " entre " + minimo +
                    " y " + maximo);
                string cadenaResultado = Console.ReadLine();
                resultado = double.Parse(cadenaResultado);
            } while ((resultado < minimo) || (resultado > maximo));
            return resultado;
        }

        const double MAX_ANCHURA = 5.0;
        const double MIN_ANCHURA = 0.5;

        public static void Main()
        {
            double anchuraVentana = leerValor(
                "Introduzca anchura de ventana: ", MIN_ANCHURA, MAX_ANCHURA);

            Console.WriteLine("Anchura: " + anchuraVentana);

            double edad = leerValor("Introduzca su edad: ", 0, 70);

            Console.WriteLine("Edad: " + edad);
            Console.ReadKey();
        }
    }