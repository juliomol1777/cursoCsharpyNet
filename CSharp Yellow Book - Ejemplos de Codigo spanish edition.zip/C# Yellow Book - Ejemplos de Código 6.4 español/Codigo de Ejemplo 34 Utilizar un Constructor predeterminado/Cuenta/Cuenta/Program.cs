﻿using System;

class Cuenta
{
    // miembros de datos privados
    private string nombre;
    private string direccion;
    private decimal saldo;

    // constructor
    public Cuenta(string enNombre, string enDireccion,
      decimal enSaldo)
    {
        nombre = enNombre;
        direccion = enDireccion;
        saldo = enSaldo;
    }
}

class Banco
{
    public static void Main()
    {
        Cuenta cuentaDeRob;
        cuentaDeRob = new Cuenta("Rob", "Casa de Rob", 1000000);
    }
}