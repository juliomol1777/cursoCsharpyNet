﻿using System;
using System.IO;
    class DemoEscrituraYLecturaArchivo
    {
        static void Main(string[] args)
        {
            StreamWriter escribir;
            escribir = new StreamWriter("prueba.txt");
            escribir.WriteLine("Hola, mundo");
            escribir.Close();

            StreamReader leer = new StreamReader("Prueba.txt");
            while (leer.EndOfStream == false)
            {
                string linea = leer.ReadLine();
                Console.WriteLine(linea);
            }
            leer.Close();
            Console.ReadKey();
        }
    }