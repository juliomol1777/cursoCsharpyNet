﻿using System;

class Cuenta
{
    public string Nombre;
};

class DemoEstructurasYObjetos
{
    public static void Main()
    {
        Cuenta CuentaDeRob;
        CuentaDeRob.Nombre = "Rob";
        Console.WriteLine(CuentaDeRob.Nombre);
    }
}