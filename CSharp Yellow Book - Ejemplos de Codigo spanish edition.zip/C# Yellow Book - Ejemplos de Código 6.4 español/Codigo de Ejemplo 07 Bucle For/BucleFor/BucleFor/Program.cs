﻿using System;

class BucleFor
{
    static void Main(string[] args)
    {
        int i;
        for (i = 1; i < 11; i = i + 1)
        {
            Console.WriteLine("Hola, mamá");
        }
        Console.ReadKey();
    }
}