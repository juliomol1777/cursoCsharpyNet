﻿using System;

public interface ICuenta
{
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
    string CadenaCartaDesagradable();
}
public abstract class Cuenta : ICuenta
{
    private decimal saldo = 0;

    public abstract string CadenaCartaDesagradable();

    public virtual bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }
}

public class CuentaCliente : Cuenta
{
    public override string CadenaCartaDesagradable()
    {
        return "Tiene la cuenta al descubierto";
    }
}

public class CuentaInfantil : Cuenta
{
    public override bool RetirarEfectivo(decimal cantidad)
    {
        if (cantidad > 10)
        {
            return false;
        }
        return base.RetirarEfectivo(cantidad);
    }
    public override string CadenaCartaDesagradable()
    {
        return "Dile a papá que tienes la cuenta al descubierto";
    }
}

class Banco
{
    const int MAX_CLIENTES = 100;

    public static void Main()
    {
        ICuenta[] cuentas = new ICuenta[MAX_CLIENTES];

        cuentas[0] = new CuentaCliente();
        Console.WriteLine("Cuenta: " + cuentas[0].CadenaCartaDesagradable());

        cuentas[1] = new CuentaInfantil();
        Console.WriteLine("Cuenta Infantil: " + cuentas[1].CadenaCartaDesagradable());

        Console.ReadKey();
    }
}