﻿using System;
    class DemoExcepcion
    {
        static void Main(string[] args)
        {
            int edad;

            Console.Write("Introduzca su edad: ");

            string cadenaEdad = Console.ReadLine();

            try
            {
                edad = int.Parse(cadenaEdad);
                Console.WriteLine("Gracias");
            }
            catch
            {
                Console.WriteLine("Valor de la edad no válido");
            }
        Console.ReadKey();
    }
}