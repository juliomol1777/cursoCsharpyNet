﻿using System;
    class MetodoDeDemostracion
    {
        static void hazesto()
        {
            Console.WriteLine("Hola");
        }
        public static void Main()
        {
            hazesto();
            hazesto();
            Console.ReadKey();
        }
    }