﻿using System;
using System.Collections.Generic;

public interface ICuenta
{
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
    string ObtenerNombre();

    bool Guardar(string nombredearchivo);
    void Guardar(System.IO.TextWriter textoDeSalida);
}

public class CuentaCliente : ICuenta
{
    public CuentaCliente(
        string nuevoNombre,
        decimal saldoInicial)
    {
        nombre = nuevoNombre;
        saldo = saldoInicial;
    }

    private decimal saldo = 0;
    private string nombre;

    public virtual bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }

    public string ObtenerNombre()
    {
        return nombre;
    }
    public virtual void Guardar(System.IO.TextWriter textoDeSalida)
    {
        textoDeSalida.WriteLine(nombre);
        textoDeSalida.WriteLine(saldo);
    }

    public bool Guardar(string nombredearchivo)
    {
        System.IO.TextWriter textoDeSalida = null;
        try
        {
            textoDeSalida = new System.IO.StreamWriter(nombredearchivo);
            Guardar(textoDeSalida);
        }
        catch
        {
            return false;
        }
        finally
        {
            if (textoDeSalida != null)
            {
                textoDeSalida.Close();
            }
        }
        return true;
    }

    public static CuentaCliente Cargar(
        System.IO.TextReader textoEn)
    {
        CuentaCliente resultado = null;

        try
        {
            string nombre = textoEn.ReadLine();
            string textoSaldo = textoEn.ReadLine();
            decimal saldo = decimal.Parse(textoSaldo);
            resultado = new CuentaCliente(nombre, saldo);
        }
        catch
        {
            return null;
        }
        return resultado;
    }

    public static CuentaCliente Cargar(string nombredearchivo)
    {
        System.IO.TextReader textoEn = null;
        CuentaCliente resultado = null;
        try
        {
            textoEn = new System.IO.StreamReader(nombredearchivo);
            resultado = CuentaCliente.Cargar(textoEn);
        }
        catch
        {
            return null;
        }
        finally
        {
            if (textoEn != null) textoEn.Close();
        }

        return resultado;
    }

    public CuentaCliente(System.IO.TextReader textoEn)
    {
        nombre = textoEn.ReadLine();
        string textoSaldo = textoEn.ReadLine();
        saldo = decimal.Parse(textoSaldo);
    }

}

public class CuentaInfantil : CuentaCliente
{
    private string nombrePadre;

    public string ObtenerNombrePadre()
    {
        return nombrePadre;
    }

    public override bool RetirarEfectivo(decimal cantidad)
    {
        if (cantidad > 10)
        {
            return false;
        }
        return base.RetirarEfectivo(cantidad);
    }

    public override void Guardar(System.IO.TextWriter textoDeSalida)
    {
        base.Guardar(textoDeSalida);
        textoDeSalida.WriteLine(nombrePadre);
    }

    public CuentaInfantil(
        string nuevoNombre,
        decimal saldoInicial,
        string nombrePadreEn)
        : base(nuevoNombre, saldoInicial)
    {
        nombrePadre = nombrePadreEn;
    }
    public CuentaInfantil(System.IO.TextReader textoEn) :
        base(textoEn)
    {
        nombrePadre = textoEn.ReadLine();
    }
}


class DiccionarioBancario
{
    Dictionary<string, ICuenta> diccionarioDeCuentas = new Dictionary<string, ICuenta>();

    public ICuenta EncontrarCuenta(string nombre)
    {
        if (diccionarioDeCuentas.ContainsKey(nombre) == true)
            return diccionarioDeCuentas[nombre];
        else
            return null;
    }

    public bool AlmacenarCuenta(ICuenta cuenta)
    {
        if (diccionarioDeCuentas.ContainsKey(cuenta.ObtenerNombre()) == true)
            return false;

        diccionarioDeCuentas.Add(cuenta.ObtenerNombre(), cuenta);
        return true;
    }

    public void Guardar(System.IO.TextWriter textoDeSalida)
    {
        textoDeSalida.WriteLine(diccionarioDeCuentas.Count);
        foreach (CuentaCliente cuenta in diccionarioDeCuentas.Values)
        {
            textoDeSalida.WriteLine(cuenta.GetType().Name);
            cuenta.Guardar(textoDeSalida);
        }
    }

    public bool Guardar(string nombredearchivo)
    {
        System.IO.TextWriter textoDeSalida = null;
        try
        {
            textoDeSalida = new System.IO.StreamWriter(nombredearchivo);
            Guardar(textoDeSalida);
        }
        catch
        {
            return false;
        }
        finally
        {
            if (textoDeSalida != null)
            {
                textoDeSalida.Close();
            }
        }
        return true;
    }

    public static DiccionarioBancario Cargar(System.IO.TextReader textoEn)
    {
        DiccionarioBancario resultado = new DiccionarioBancario();
        string contarCadena = textoEn.ReadLine();
        int contador = int.Parse(contarCadena);

        for (int i = 0; i < contador; i++)
        {
            string nombreClase = textoEn.ReadLine();
            ICuenta cuenta =
                FabricaDeCuentas.CrearCuenta(nombreClase, textoEn);
            resultado.AlmacenarCuenta(cuenta);
        }
        return resultado;
    }

    public static DiccionarioBancario Cargar(string nombredearchivo)
    {
        System.IO.TextReader textoEn = null;
        DiccionarioBancario resultado = null;
        try
        {
            textoEn = new System.IO.StreamReader(nombredearchivo);
            resultado = DiccionarioBancario.Cargar(textoEn);
        }
        catch
        {
            return null;
        }
        finally
        {
            if (textoEn != null) textoEn.Close();
        }

        return resultado;
    }

}

class FabricaDeCuentas
{
    public static ICuenta CrearCuenta(
        string nombre, System.IO.TextReader textoEn)
    {
        switch (nombre)
        {
            case "CuentaCliente":
                return new CuentaCliente(textoEn);
            case "CuentaInfantil":
                return new CuentaInfantil(textoEn);
            default:
                return null;
        }
    }
}


class ProgramaBancario
{
    public static void Main()
    {
        DiccionarioBancario nuestroBanco = new DiccionarioBancario();

        CuentaCliente nuevaCuenta = new CuentaCliente("Rob", 1000000);

        if (nuestroBanco.AlmacenarCuenta(nuevaCuenta))
            Console.WriteLine("CuentaCliente añadida al banco");

        CuentaInfantil nuevaCuentaInfantil = new CuentaInfantil("David", 100, "Rob");

        if (nuestroBanco.AlmacenarCuenta(nuevaCuentaInfantil))
            Console.WriteLine("CuentaInfantil añadida al banco");

        nuestroBanco.Guardar("Prueba.txt");

        DiccionarioBancario cargarBanco = DiccionarioBancario.Cargar("Prueba.txt");

        ICuenta cuentaAlmacenada = cargarBanco.EncontrarCuenta("Rob");
        if (cuentaAlmacenada != null)
            Console.WriteLine("CuentaCliente encontrada en el banco");
        cuentaAlmacenada = cargarBanco.EncontrarCuenta("David");
        if (cuentaAlmacenada != null)
            Console.WriteLine("CuentaInfantil encontrada en el banco");

        Console.ReadKey();
    }
}