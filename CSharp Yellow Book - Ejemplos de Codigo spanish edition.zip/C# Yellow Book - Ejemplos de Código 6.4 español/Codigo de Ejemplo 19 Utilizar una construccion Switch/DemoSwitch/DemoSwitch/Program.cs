﻿using System;
    class DemoSwitch
    {
        static string leerCadena(string prompt)
        {
            string resultado;
            do
            {
                Console.Write(prompt);
                resultado = Console.ReadLine();
            } while (resultado == "");
            return resultado;
        }

        static int leerEntero(string prompt, int minimo, int maximo)
        {
            int resultado;

            do
            {
                string cadenaEntero = leerCadena(prompt);

            resultado = int.Parse(cadenaEntero);
            } while ((resultado < minimo) || (resultado > maximo));

            return resultado;
        }

        static void ventanaAbatible()
        {
            Console.WriteLine("Ventana Abatible");
        }

        static void ventanaEstandar()
        {
            Console.WriteLine("Ventana Estándar");
        }

        static void puertaDelPatio()
        {
            Console.WriteLine("Puerta del patio");
        }
    static void Main(string[] args)
        {
            int seleccion;
            seleccion = leerEntero("Tipo de ventana: ", 1, 3);

            switch (seleccion)
            {
                case 1:
                    ventanaAbatible();
                    break;
                case 2:
                    ventanaEstandar();
                    break;
                case 3:
                    puertaDelPatio();
                    break;
                default:
                    Console.WriteLine("Número no válido");
                    break;
            }
            Console.ReadKey();
        }
    }