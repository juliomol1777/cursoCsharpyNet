﻿using System;

class Cuenta
{
    // miembros de datos privados
    private string nombre;
    private string direccion;
    private decimal saldo;

    // constructores
    public Cuenta(string enNombre, string enDireccion,
      decimal enSaldo)
    {
        nombre = enNombre;
        direccion = enDireccion;
        saldo = enSaldo;
    }
    public Cuenta(string enNombre, string enDireccion) :
        this(enNombre, enDireccion, 0)
    {
    }

    public Cuenta(string enNombre):
        this(enNombre, "No Suministrado", 0)
    {
    }
}

class Banco
{
    public static void Main()
    {
        const int MAX_CLIENTES = 100;
        Cuenta[] Cuentas = new Cuenta[MAX_CLIENTES];
        Cuentas[0] = new Cuenta("Rob", "Casa de Rob", 1000000);
        Cuentas[1] = new Cuenta("Jim", "Casa de Jim");
        Cuentas[2] = new Cuenta("Fred");
    }
}