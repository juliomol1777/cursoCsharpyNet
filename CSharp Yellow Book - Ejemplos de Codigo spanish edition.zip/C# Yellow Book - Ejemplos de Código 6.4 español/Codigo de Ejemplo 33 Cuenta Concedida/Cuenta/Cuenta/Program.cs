﻿using System;

public class Cuenta
{
    private decimal saldo = 0;

    public bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }

    private static decimal ingresoMin;
    private static int edadMin;

    public static bool CuentaConcedida(decimal ingreso, int edad)
    {
        if ((ingreso >= 10000) && (edad >= 18))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}

class Banco
{
    public static void Main()
    {
        if (Cuenta.CuentaConcedida(25000, 21))
        {
            Console.WriteLine("Cuenta concedida");
        }
        Console.ReadKey();
    }
}