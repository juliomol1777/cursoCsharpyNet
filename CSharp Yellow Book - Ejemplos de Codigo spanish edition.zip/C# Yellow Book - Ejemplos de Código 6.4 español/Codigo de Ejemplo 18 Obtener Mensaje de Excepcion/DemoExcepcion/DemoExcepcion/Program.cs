﻿using System;
    class DemoExcepcion
    {
        static void Main(string[] args)
        {
            int edad;

            Console.Write("Introduzca su edad: ");

            string cadenaEdad = Console.ReadLine();

            try
            {
                edad = int.Parse(cadenaEdad);
                Console.WriteLine("Gracias");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }