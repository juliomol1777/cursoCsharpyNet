﻿using System;

class BucleWhileActuandoComoBucleFor
{
    static void Main(string[] args)
    {
        int i;
        i = 1;
        while (i < 11)
        {
            Console.WriteLine("Hola, mamá");
            i = i + 1;
        }
        Console.ReadKey();
    }
}