﻿using System;
    class MetodoDeDemostracion
    {

        static void absurdo(int i)
        {
            Console.WriteLine("i vale: " + i);
        }
        static void Main(string[] args)
        {
            absurdo(101);
            absurdo(500);
            Console.ReadKey();
        }
    }