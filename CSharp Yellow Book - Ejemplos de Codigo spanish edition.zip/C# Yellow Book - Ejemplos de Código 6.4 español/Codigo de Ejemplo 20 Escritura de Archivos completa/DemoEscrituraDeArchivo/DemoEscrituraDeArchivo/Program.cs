﻿using System;
using System.IO;
class DemoEscrituraDeArchivo
    {
        static void Main(string[] args)
        {
            StreamWriter escritor;
            escritor = new StreamWriter("prueba.txt");
            escritor.WriteLine("Hola, mundo");
            escritor.Close();
            Console.ReadKey();
        }
    }