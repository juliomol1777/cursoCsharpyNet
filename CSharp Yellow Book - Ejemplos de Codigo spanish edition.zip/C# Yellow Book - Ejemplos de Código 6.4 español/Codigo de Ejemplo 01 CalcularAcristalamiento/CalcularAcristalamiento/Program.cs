﻿using System;

class CalcularAcristalamiento
{
    static void Main()
    {
        double anchura, altura, longitudMadera, areaVidrio;
        string cadenaAnchura, cadenaAltura;

        cadenaAnchura = Console.ReadLine();
        anchura = double.Parse(cadenaAnchura);

        cadenaAltura = Console.ReadLine();
        altura = double.Parse(cadenaAltura);

        longitudMadera = 2 * (anchura + altura) * 3.25;

        areaVidrio = 2 * (anchura * altura);

        Console.WriteLine("La longitud de la madera es" +
                longitudMadera + " pies");
        Console.WriteLine("El área del vidrio es " +
               areaVidrio + " metros cuadrados");
    }
}