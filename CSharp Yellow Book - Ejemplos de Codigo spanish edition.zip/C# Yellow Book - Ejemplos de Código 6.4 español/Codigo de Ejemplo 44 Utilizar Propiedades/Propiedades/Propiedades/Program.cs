﻿using System;

public class Empleado
{
    private int valorEdad;

    public int Edad
    {
        set
        {
            if ((value > 0) && (value < 120))
            {
                this.valorEdad = value;
            }
        }
        get
        {
            return this.valorEdad;
        }
    }
}

public class StaffDemo
{
    public static void Main()
    {
        Empleado e = new Empleado();
        e.Edad = 21;
        Console.WriteLine("Edad : " + e.Edad);
        Console.ReadKey();
    }
}