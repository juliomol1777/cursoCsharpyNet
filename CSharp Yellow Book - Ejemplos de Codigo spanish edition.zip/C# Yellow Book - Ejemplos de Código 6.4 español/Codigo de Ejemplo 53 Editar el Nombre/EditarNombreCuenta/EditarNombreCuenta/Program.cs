﻿using System;

public interface ICuenta
{
    string ObtenerNombre();
    bool EstablecerNombre(string nuevoNombre);
}

public class CuentaCliente : ICuenta
{
    private string nombre;

    public string ObtenerNombre()
    {
        return this.nombre;
    }

    public static string ValidarNombre(string nombre)
    {
        if (nombre == null)
        {
            return "Parámetro nombre null";
        }
        string nombreDeEspaciosEnBlanco = nombre.Trim();
        if (nombreDeEspaciosEnBlanco.Length == 0)
        {
            return "El nombre introducido no contiene texto";
        }
        return "";
    }

    public bool EstablecerNombre(string enNombre)
    {
        string respuesta;
        respuesta = ValidarNombre(enNombre);
        if (respuesta.Length > 0)
        {
            return false;
        }

        this.nombre = enNombre.Trim();
        return true;
    }

    private decimal saldo;

    public CuentaCliente(string enNombre, decimal enSaldo)
    {
        string respuesta = "";

        string validar = ValidarNombre(enNombre);
        if (validar != "")
            respuesta = respuesta + validar;

        // Realmente debería realizar la validación del saldo aquí
        saldo = enSaldo;

        // Falla si hay algún mensaje de error
        if (respuesta != "")
            throw new Exception(respuesta);
    }
}

public class IUModificarTextoDeCuenta
{
    private ICuenta cuenta;

    public IUModificarTextoDeCuenta(ICuenta cuentaEn)
    {
        this.cuenta = cuentaEn;
    }

    public void ModificarNombre()
    {
        string nuevoNombre;
        Console.WriteLine("Modificar nombre");
        while (true)
        {
            Console.Write("Introduzca un nuevo nombre: ");
            nuevoNombre = Console.ReadLine();
            string respuesta;
            respuesta = CuentaCliente.ValidarNombre(nuevoNombre);

            if (respuesta.Length == 0)
            {
                break;
            }
            Console.WriteLine("Nombre no válido : " + respuesta);
        }
        this.cuenta.EstablecerNombre(nuevoNombre);
    }
}


class ModificarNombre
{
    public static void HacerSonarSirena()
    {
        Console.WriteLine("Insertar el sonido fuerte aquí");
    }

    public static void Main()
    {
        CuentaCliente a = new CuentaCliente("Rob", 50);
        IUModificarTextoDeCuenta modificar = new IUModificarTextoDeCuenta(a);
        modificar.ModificarNombre();
    }
}