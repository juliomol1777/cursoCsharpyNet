﻿using System;

public interface ICuenta
{
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
}

public class CuentaCliente : ICuenta
{

    private decimal saldo = 0;

    public bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }
}


class Banco
{
    public static void Main()
    {
        ICuenta cuenta = new CuentaCliente();
        cuenta.IngresarEfectivo(50);
        Console.WriteLine("Saldo: " + cuenta.ObtenerSaldo());
        Console.ReadKey();
    }
}