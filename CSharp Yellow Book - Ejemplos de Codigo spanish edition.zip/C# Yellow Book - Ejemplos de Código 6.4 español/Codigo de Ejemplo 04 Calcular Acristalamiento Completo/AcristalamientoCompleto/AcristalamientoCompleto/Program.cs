﻿using System;

    class CalcularAcristalamiento
    {
        static void Main(string[] args)
        {
            double anchura, altura, longitudMadera, areaVidrio;

            const double MAX_ANCHURA = 5.0;
            const double MIN_ANCHURA = 0.5;
            const double MAX_ALTURA = 3.0;
            const double MIN_ALTURA = 0.75;

            string cadenaAnchura, cadenaAltura;

            Console.Write("Introduzca la anchura de la ventana: ");
            cadenaAnchura = Console.ReadLine();
            anchura = double.Parse(cadenaAnchura);

            if (anchura < MIN_ANCHURA)
            {
                Console.WriteLine("Anchura demasiado pequeña.\n\n");
                Console.WriteLine("Usando la mínima permitida");
                anchura = MIN_ANCHURA;
            }

            if (anchura > MAX_ANCHURA)
            {
                Console.WriteLine("Anchura demasiado grande.\n\n");
                Console.WriteLine("Usando la máxima permitida");
                anchura = MAX_ANCHURA;
            }

            Console.Write("Introduzca la altura de la ventana: ");
            cadenaAltura = Console.ReadLine();
            altura = double.Parse(cadenaAltura);

            if (altura < MIN_ALTURA)
            {
                Console.WriteLine("\nAltura demasiado pequeña.");
                Console.WriteLine("Usando la mínima permitida");
                altura = MIN_ALTURA;
            }
            if (altura > MAX_ALTURA)
            {
                Console.WriteLine("\nAltura demasiado grande.");
                Console.WriteLine("Usando la máxima permitida");
                altura = MAX_ALTURA;
            }

        longitudMadera = 2 * (anchura + altura) * 3.25;

        areaVidrio = 2 * (anchura * altura);

        Console.WriteLine("\nLa longitud de la madera es de " +
                longitudMadera + " pies");
        Console.WriteLine("El área de vidrio es de " +
                areaVidrio + " metros cuadrados");
        Console.ReadKey();
        }
    }