﻿using System;
using System.Collections;

public interface ICuenta
{
    bool EstablecerNombre(string enNombre);
    string ObtenerNombre();
    bool EstablecerDireccion(string enDireccion);
    string ObtenerDireccion();
    void IngresarEfectivo(decimal cantidad);
    bool RetirarEfectivo(decimal cantidad);
    decimal ObtenerSaldo();
}

public class Cuenta : ICuenta
{

    private string nombre;

    public bool EstablecerNombre(string enNombre)
    {
        if (enNombre == "")
            return false;

        nombre = enNombre;

        return true;
    }

    public string ObtenerNombre()
    {
        return nombre;
    }

    private string direccion;

    public bool EstablecerDireccion(string enDireccion)
    {
        if (enDireccion == "")
            return false;

        direccion = enDireccion;

        return true;
    }

    public string ObtenerDireccion()
    {
        return direccion;
    }

    const decimal MAX_SALDO = 10000000;
    const decimal MIN_SALDO = -10000000;
    private decimal saldo;

    public bool EstablecerSaldo(decimal enSaldo)
    {
        if (enSaldo < MIN_SALDO ||
            enSaldo > MAX_SALDO)
            return false;

        saldo = enSaldo;
        return true;
    }

    // constructores
    public Cuenta(string enNombre, string enDireccion,
      decimal enSaldo)
    {
        string mensajeError = "";

        if (EstablecerSaldo(enSaldo) == false)
            mensajeError = mensajeError + enSaldo + " saldo no válido:";

        if (EstablecerNombre(enNombre) == false)
        {
            mensajeError = mensajeError + enNombre + " nombre no válido";
        }

        if (EstablecerDireccion(enDireccion) == false)
        {
            mensajeError = mensajeError + enDireccion + " dirección no válida";
        }

        if (mensajeError != "")
        {
            throw new Exception("Creación de la cuenta fallida "
                + mensajeError);
        }
    }

    public Cuenta(string enNombre) :
        this(enNombre, "No suministrado", 0)
    {
    }

    public bool RetirarEfectivo(decimal cantidad)
    {
        if (saldo < cantidad)
        {
            return false;
        }
        saldo = saldo - cantidad;
        return true;
    }

    public void IngresarEfectivo(decimal cantidad)
    {
        saldo = saldo + cantidad;
    }

    public decimal ObtenerSaldo()
    {
        return saldo;
    }
}


class HashBancario
{
    Hashtable tablaHashBancaria = new Hashtable();

    public ICuenta EncontrarCuenta(string nombre)
    {
        return tablaHashBancaria[nombre] as ICuenta;
    }

    public bool AlmacenarCuenta(ICuenta cuenta)
    {
        tablaHashBancaria.Add(cuenta.ObtenerNombre(), cuenta);
        return true;
    }
}

class ProgramaBancario
{

    public static void Main()
    {
        HashBancario nuestroBanco = new HashBancario();

        Cuenta nuevaCuenta = new Cuenta("Rob", "Casa de Rob", 1000000);

        if (nuestroBanco.AlmacenarCuenta(nuevaCuenta) == true)
            Console.WriteLine("Cuenta añadida al banco");

        ICuenta cuentaAlmacenada = nuestroBanco.EncontrarCuenta("Rob");
        if (cuentaAlmacenada != null)
            Console.WriteLine("Cuenta encontrada en el banco");
        Console.ReadKey();
    }
}