﻿using System;
    enum Semaforo
    {
        Rojo,
        RojoAmbar,
        Verde,
        Ambar
    };
    class DemoEnumaracion
    {
        static void Main(string[] args)
        {
            Semaforo luz;
            luz = Semaforo.Rojo;
            Console.WriteLine(luz);
            Console.ReadKey();
        }
    }