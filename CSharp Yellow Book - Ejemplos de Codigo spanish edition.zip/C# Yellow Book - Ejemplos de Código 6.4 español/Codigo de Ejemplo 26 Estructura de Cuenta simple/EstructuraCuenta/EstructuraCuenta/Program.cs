﻿using System;

    struct EstructuraCuenta
    {
        public string Nombre;
    };

    class DemoEstructurasYObjetos
    {
        static void Main(string[] args)
        {
            EstructuraCuenta EstructuraCuentaDeRob;
            EstructuraCuentaDeRob.Nombre = "Rob";
            Console.WriteLine(EstructuraCuentaDeRob.Nombre);
            Console.ReadKey();
        }
    }