﻿using System.Threading;
class DemoHilo
{
    static private void bucleOcupado()
    {
        long contador;
        for (contador = 0; contador < 1000000000000L; contador = contador + 1)
        {
        }
    }

    static void Main()
    {
        for (int i = 0; i < 100; i = i + 1)
        {
            Thread t1 = new Thread(bucleOcupado);
            t1.Start();
        }
    }
}