﻿using System;
class Punto
{
    public int x;
    public int y;
    public override bool Equals(object obj)
    {
        Punto p = (Punto)obj;
        if ((p.x == x) && (p.y == y))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public Punto(int inX, int inY)
    {
        x = inX;
        y = inY;
    }
}


class Videojuego
{
    public static void Main()
    {
        Punto posicionNaveEspacial = new Punto(10, 10);
        Punto posicionMisil = new Punto(10, 10);
        if (posicionMisil.Equals(posicionNaveEspacial))
        {
            Console.WriteLine("Bang");
        }
        Console.ReadKey();
    }
}